<?php

function sb_test_function()
{
	return 'something' ;
}
