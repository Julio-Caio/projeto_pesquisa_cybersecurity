<?php

namespace SmashBalloon\Reviews\Common\Integrations\Providers;

class Google extends BaseProvider
{
    protected $name = 'google';
    protected $friendly_name = 'Google';
}