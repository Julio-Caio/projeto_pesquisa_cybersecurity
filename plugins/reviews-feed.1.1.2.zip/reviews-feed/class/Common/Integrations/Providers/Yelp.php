<?php

namespace SmashBalloon\Reviews\Common\Integrations\Providers;

class Yelp extends BaseProvider
{
    protected $name = 'yelp';
    protected $friendly_name = 'Yelp';
}