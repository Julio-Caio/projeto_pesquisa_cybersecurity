<?php

namespace SmashBalloon\Reviews\Common\Builder\Config;

class Proxy extends \Smashballoon\Customizer\V2\Config\Proxy {
    public $parent_menu_slug = SBR_MENU_SLUG;
    public $menu_slug = SBR_MENU_SLUG;
    public $menu_title = "Reviews Feed";
    public $page_title = "Reviews Feed";
}