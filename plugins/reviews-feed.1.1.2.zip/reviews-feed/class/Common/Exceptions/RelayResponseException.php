<?php

namespace SmashBalloon\Reviews\Common\Exceptions;

class RelayResponseException extends BaseException {



}