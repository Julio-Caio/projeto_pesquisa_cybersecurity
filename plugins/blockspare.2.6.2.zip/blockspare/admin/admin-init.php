<?php

/**
 * Admin screen.
 */

include(BLOCKSPARE_PLUGIN_DIR . 'admin/index.php');

