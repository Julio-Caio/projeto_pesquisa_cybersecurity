<?php 

function banner_control_slider($attributes,$blockuniqueclass,$blockName=''){
    $block_content = '';
    $block_content .= '<style type="text/css">';

    //Slider Title Meta Color
    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-grid-title a span{
        color:'.$attributes['sliderPostTitleColor'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-content .blockspare-posts-block-post-grid-title{
        line-height:'.$attributes['sliderTitleLineHeight'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-grid-author a span{
        color:'.$attributes['sliderPostLinkColor'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-slider-wrapper .blockspare-posts-block-text-link a{
        color:'.$attributes['sliderPostLinkColor'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-grid-date{
        color:'.$attributes['sliderPostGeneralColor'].';
    }';
    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-slider-wrapper .comment_count{
        color:'.$attributes['sliderPostGeneralColor'].';
    }';

    // slider background color 

    if($blockName == 'blockspare-banner-11') {
        $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-post-data .blockspare-posts-block-post-content{
            background-color: ' . $attributes['sliderBackgroundColor'] . ';
            
        }'; 
    }

    //sliderTitle Hover

  if($attributes['sliderTitleOnHover']=='lpc-title-hover') {
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-posts-block-post-content.has-slider-title-hover .blockspare-posts-block-title-link:hover span{
        color: ' . $attributes['sliderTitleOnHoverColor'] . ';
        
         }';
    }

if($attributes['sliderTitleOnHover']=='lpc-title-border') {
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-posts-block-post-content.has-slider-title-hover .blockspare-posts-block-post-grid-title .blockspare-posts-block-title-link span:hover{
        box-shadow: inset 0 -2px 0 0 ' . $attributes['sliderTitleOnHoverColor'] . ';
        
         }';
}
//slider title Gaps
$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-banner-slider .blockspare-posts-block-post-grid-title{
   margin-top: ' . $attributes['sliderTitleMarginTop'] ."px". ';
   margin-Bottom: ' . $attributes['sliderTitleMarginBottom'] ."px". ';
   margin-left: ' . $attributes['sliderTitleMarginLeft'] ."px". ';
   margin-right: ' . $attributes['sliderTitleMarginRight'] ."px". ';
}';
   

//slider category Gaps
$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-banner-slider .blockspare-posts-block-post-category{
    margin-top: ' . $attributes['sliderCategoryMarginTop'] ."px". ';
    margin-Bottom: ' . $attributes['sliderCategoryMarginBottom'] ."px". ';
    margin-left: ' . $attributes['sliderCategoryMarginLeft'] ."px". ';
    margin-right: ' . $attributes['sliderCategoryMarginRight'] ."px". ';
}';

//slider meta Gaps
$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-banner-slider .blockspare-posts-block-post-grid-byline{
    margin-top: ' . $attributes['sliderMetaMarginTop'] ."px". ';
    margin-Bottom: ' . $attributes['sliderMetaMarginBottom'] ."px". ';
    margin-left: ' . $attributes['sliderMetaMarginLeft'] ."px". ';
    margin-right: ' . $attributes['sliderMetaMarginRight'] ."px". ';
}';

///block Gaps
$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-wrapper{
    --gap: ' . $attributes['gutter'] ."px". ';
    margin-top: ' . $attributes['marginTop'] ."px". ';
    margin-Bottom: ' . $attributes['marginBottom'] ."px". ';
    margin-left: ' . $attributes['marginLeft'] ."px". ';
    margin-right: ' . $attributes['marginRight'] ."px". ';
}';

///content Gaps
$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-wrapper .blockspare-banner-slider-wrapper .blockspare-posts-block-post-content{
    padding-top: ' . $attributes['contentPaddingTop'] ."px". ';
    padding-Bottom: ' . $attributes['contentPaddingBottom'] ."px". ';
    padding-left: ' . $attributes['contentPaddingLeft'] ."px". ';
    padding-right: ' . $attributes['contentPaddingRight'] ."px". ';
}';

$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-wrapper .blockspare-editor-picks-items .blockspare-posts-block-post-content{
    padding-top: ' . $attributes['contentPaddingTop'] ."px". ';
    padding-Bottom: ' . $attributes['contentPaddingBottom'] ."px". ';
    padding-left: ' . $attributes['contentPaddingLeft'] ."px". ';
    padding-right: ' . $attributes['contentPaddingRight'] ."px". ';
}';

///border radius
$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-wrapper .blockspare-banner-slider-wrapper{
    border-radius: ' . $attributes['borderRadius'] ."px". ';
    overflow: ' . "hidden" . ';
}';

$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-wrapper .blockspare-editor-picks-items .blockspare-post-items{
    border-radius: ' . $attributes['borderRadius'] ."px". ';
    overflow: ' . "hidden" . ';
}';

$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-wrapper .blockspare-banner-trending-carousel-wrapper .blockspare-post-items{
    border-radius: ' . $attributes['borderRadius'] ."px". ';
    overflow: ' . "hidden" . ';
}';





    //slider Category color
    if ($attributes['sliderCategoryLayoutOption'] == 'solid') {
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-category a{
            color:' . $attributes['sliderCategoryTextColor'] . "!important" . ';
            background-color:' . $attributes['sliderCategoryBackgroundColor'] . "!important" . ';
            border-radius:' . $attributes['sliderCategoryBorderRadius'] . "px" . ';
        }';
  
        } else if ($attributes['sliderCategoryLayoutOption'] == 'border') {
            
                $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-category a{
                color:' . $attributes['sliderCategoryTextColor'] . "!important" . ';
                background-color:' . "transparent" . ';
                border:' . "1px solid" . $attributes['sliderCategoryBorderColor'] . ';
                border-radius:' . $attributes['sliderCategoryBorderRadius'] . "px" . ';
                border-width:' . $attributes['sliderCategoryBorderWidth'] . "px" . ';
            }';
            
            
            
        } else {
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-category a{
                color:' . $attributes['sliderCategoryTextColor'] . "!important" . ';
                }';
        }

    //slider nav color
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper span:before{
        color:' . $attributes['sliderNavigationColor'].';
        }';

    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-wrap .blockspare-banner-slider-wrapper .slick-slider .slick-dots > li button{
        background-color:' . $attributes['sliderNavigationColor'].';
        }'; 

    if($attributes['sliderNextPrevShow']) {
        if($attributes['sliderNavigationShape'] === 'bs-navigation-1' ||  $attributes['sliderNavigationShape']  === 'bs-navigation-2' ) {
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider .slick-arrow:after{
                background-color:' . $attributes['sliderNavigationShapeColor'].';
                }'; 
        }elseif($attributes['sliderNavigationShape']  === 'bs-navigation-3' ||  $attributes['sliderNavigationShape']  === 'bs-navigation-4' ){
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider .slick-arrow{
                border-color:' . $attributes['sliderNavigationShapeColor'].';
                }'; 
        }else{
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider .slick-slider .slick-arrow{
                border-color:'."transparent".';
                background-color:'."transparent".';
                }'; 

        }
    }  
    
    //slider overlay color
    if($blockName == 'blockspare-banner-1' || $blockName == 'blockspare-banner-2' || $blockName == 'blockspare-banner-3' || $blockName == 'blockspare-banner-4'){
        if($attributes['bannerOneLayout'] === 'banner-style-1 has-bg-layout' || $attributes['bannerOneLayout'] === 'banner-style-2 has-bg-layout' || $attributes['bannerTwoLayout'] === 'banner-style-1 has-bg-layout' || $attributes['bannerTwoLayout'] === 'banner-style-2 has-bg-layout' || $attributes['bannerThreeLayout'] === 'banner-style-1 has-bg-layout' || $attributes['bannerThreeLayout'] === 'banner-style-2 has-bg-layout' || $attributes['bannerFourLayout'] === 'banner-style-1 has-bg-layout' || $attributes['bannerFourLayout'] === 'banner-style-2 has-bg-layout') {
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-post-items .blockspare-post-data .blockspare-posts-block-post-img::before{
                background:' . "linear-gradient(to bottom, rgba(0, 0, 0, 0) 40%, " . $attributes['sliderPostOverlayColor'] . " 100%)" . ';
            }'; 
        }
        if($attributes['bannerOneLayout'] === 'banner-style-3 has-bg-layout' || $attributes['bannerOneLayout'] === 'banner-style-4 has-bg-layout' || $attributes['bannerTwoLayout'] === 'banner-style-3 has-bg-layout' || $attributes['bannerTwoLayout'] === 'banner-style-4 has-bg-layout' || $attributes['bannerThreeLayout'] === 'banner-style-3 has-bg-layout' || $attributes['bannerThreeLayout'] === 'banner-style-4 has-bg-layout' || $attributes['bannerFourLayout'] === 'banner-style-3 has-bg-layout' || $attributes['bannerFourLayout'] === 'banner-style-4 has-bg-layout') {
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-post-items .blockspare-post-data .blockspare-posts-block-post-content .blockspare-posts-block-post-grid-title .blockspare-posts-block-title-link{
                background:' . $attributes['sliderPostOverlayColor'] . ';
            }'; 

            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-post-items .blockspare-post-data .blockspare-posts-block-post-content .blockspare-posts-block-post-grid-byline{
                background:' . $attributes['sliderPostOverlayColor'] . ';
            }'; 
        }
        if($attributes['bannerOneLayout'] === 'banner-style-5' || $attributes['bannerOneLayout'] === 'banner-style-6' || $attributes['bannerTwoLayout'] === 'banner-style-5' || $attributes['bannerTwoLayout'] === 'banner-style-6' || $attributes['bannerThreeLayout'] === 'banner-style-5' || $attributes['bannerThreeLayout'] === 'banner-style-6' || $attributes['bannerFourLayout'] === 'banner-style-5' || $attributes['bannerFourLayout'] === 'banner-style-6') {
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-post-items .blockspare-post-data .blockspare-posts-block-post-content::after{
                background:' . $attributes['sliderPostOverlayColor'] . ';
            }'; 
        }
        if($attributes['bannerOneLayout'] === 'banner-style-7' || $attributes['bannerOneLayout'] === 'banner-style-8' || $attributes['bannerTwoLayout'] === 'banner-style-7' || $attributes['bannerTwoLayout'] === 'banner-style-8' || $attributes['bannerThreeLayout'] === 'banner-style-7' || $attributes['bannerThreeLayout'] === 'banner-style-8' || $attributes['bannerFourLayout'] === 'banner-style-7' || $attributes['bannerFourLayout'] === 'banner-style-8') {
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-post-items .blockspare-post-data .blockspare-posts-block-post-img::before{
                background:' . $attributes['sliderPostOverlayColor'] . ';
            }'; 
        }
    } else {
        $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-post-items .blockspare-post-data .blockspare-posts-block-post-img::before{
            background:' . "linear-gradient(to bottom, rgba(0, 0, 0, 0) 40%, " . $attributes['sliderPostOverlayColor'] . " 100%)" . ';
        }'; 
    }

    
    //trending Bg color

    $bg = 'transparent';
    
    if($blockName == 'blockspare-banner-1'){
        $bg = $attributes['bannerOneTrendingBg'];
    }
    else if($blockName == 'blockspare-banner-2'){
        $bg = $attributes['bannerTwoTrendingBg']; 
    }
    else if($blockName == 'blockspare-banner-3'){
        $bg = $attributes['bannerThreeTrendingBg']; 
    }
    else if($blockName == 'blockspare-banner-4'){
        $bg = $attributes['bannerFourTrendingBg']; 
    }
    else if($blockName == 'blockspare-banner-5'){
        $bg = $attributes['bannerFiveTrendingBg']; 
    }
    else if($blockName == 'blockspare-banner-6'){
        $bg = $attributes['bannerSixTrendingBg']; 
    }
    else if($blockName == 'blockspare-banner-7'){
        $bg = $attributes['bannerSevenTrendingBg']; 
    }
    else if($blockName == 'blockspare-banner-8'){
        $bg = $attributes['bannerEightTrendingBg']; 
    }
    else if($blockName == 'blockspare-banner-9'){
        $bg = $attributes['bannerNineTrendingBg']; 
    }
    else if($blockName == 'blockspare-banner-10'){
        $bg = $attributes['bannerTenTrendingBg']; 
    }
    else if($blockName == 'blockspare-banner-11'){
        $bg = $attributes['bannerElevenTrendingBg']; 
    }
    else if($blockName == 'blockspare-banner-12'){
        $bg = $attributes['bannerTwelveTrendingBg']; 
    }

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-trending-carousel-wrapper .blockspare-post-items.has-bg-layout .blockspare-post-data{
        background-color:'.$bg.';
    }';
    
    
    //Trending Title Meta Color
    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-grid-title a span{
        color:'.$attributes['trendingPostTitleColor'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-content .blockspare-posts-block-post-grid-title{
        line-height:'.$attributes['trendingTitleLineHeight'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-grid-author a span{
        color:'.$attributes['trendingPostLinkColor'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-text-link a{
        color:'.$attributes['trendingPostLinkColor'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-grid-date{
        color:'.$attributes['trendingPostGeneralColor'].';
    }';
    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-trending-carousel-wrapper .comment_count{
        color:'.$attributes['trendingPostGeneralColor'].';
    }';

     //trending Title Hover

  if($attributes['trendingTitleOnHover']=='lpc-title-hover') {
    $block_content .= ' .' .$blockuniqueclass. ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-content.has-trending-title-hover .blockspare-posts-block-title-link:hover span{
        color: ' . $attributes['trendingTitleOnHoverColor'] . ';
        
         }';
    }

//trending title Gaps
$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-grid-title{
    margin-top: ' . $attributes['trendingTitleMarginTop'] ."px". ';
    margin-Bottom: ' . $attributes['trendingTitleMarginBottom'] ."px". ';
    margin-left: ' . $attributes['trendingTitleMarginLeft'] ."px". ';
    margin-right: ' . $attributes['trendingTitleMarginRight'] ."px". ';
}';

//trending category Gaps
$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-category{
    margin-top: ' . $attributes['trendingCategoryMarginTop'] ."px". ';
    margin-Bottom: ' . $attributes['trendingCategoryMarginBottom'] ."px". ';
    margin-left: ' . $attributes['trendingCategoryMarginLeft'] ."px". ';
    margin-right: ' . $attributes['trendingCategoryMarginRight'] ."px". ';
}';

//trending meta Gaps
$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-grid-byline{
    margin-top: ' . $attributes['trendingMetaMarginTop'] ."px". ';
    margin-Bottom: ' . $attributes['trendingMetaMarginBottom'] ."px". ';
    margin-left: ' . $attributes['trendingMetaMarginLeft'] ."px". ';
    margin-right: ' . $attributes['trendingMetaMarginRight'] ."px". ';
}';

    
if($attributes['trendingTitleOnHover']=='lpc-title-border') {
    
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-content.has-trending-title-hover .blockspare-posts-block-post-grid-title .blockspare-posts-block-title-link span:hover{
        box-shadow: inset 0 -2px 0 0 ' . $attributes['trendingTitleOnHoverColor'] . ';
        
         }';
}



    //Trending nav color
    $block_content .= ' .' . $blockuniqueclass . '  .blockspare-banner-trending-carousel-wrapper span:before{
        color:' . $attributes['trendingNavigationColor'].';
        }';

    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .slick-slider .slick-dots > li button{
        background-color:' . $attributes['trendingNavigationColor'].';
        }'; 

    if($attributes['trendingNextPrevShow']) {
        if($attributes['trendingNavigationShape'] == 'bs-navigation-1' ||  $attributes['trendingNavigationShape']  == 'bs-navigation-2' ) {
            $block_content .= ' .' . $blockuniqueclass . '  .blockspare-banner-trending-carousel-wrapper .slick-slider .slick-arrow:after{
                background-color:' . $attributes['trendingNavigationShapeColor'].';
                }'; 
        }elseif($attributes['trendingNavigationShape']  == 'bs-navigation-3' ||  $attributes['trendingNavigationShape']  == 'bs-navigation-4' ){
            $block_content .= ' .' . $blockuniqueclass . '  .blockspare-banner-trending-carousel-wrapper .slick-slider .slick-arrow{
                border-color:' . $attributes['trendingNavigationShapeColor'].';
                }'; 
        }else{
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-wrap .blockspare-banner-trending-carousel-wrapper .slick-slider .slick-arrow{
                border-color:'."transparent".';
                background-color:'."transparent".';
                }'; 

        }
    } 

    // trending tab

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-trending-tabs .components-tab-panel__tabs .blockspare-trending-tab i{
        color:'.$attributes['trendingTabIconColor'].';
        font-size:' . $attributes['trendingTabIconSize'] . "px" . ';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-trending-tabs .components-tab-panel__tabs .blockspare-trending-tab{
        color:'.$attributes['trendingTabTextColor'].';
        background-color:'.$attributes['trendingTabBgColor'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-trending-tabs .components-tab-panel__tabs .blockspare-trending-tab.active-tab{
        background-color:'.$attributes['trendingTabActiveColor'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-trending-tabs .components-tab-panel__tabs{
        border-color:' . $attributes['trendingTabActiveColor'] . " !important" . ';
    }';
    
    
    //Editor Picks Title Meta Color
    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-grid-title a span{
        color:'.$attributes['editorPostTitleColor'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-content .blockspare-posts-block-post-grid-title{
        line-height:'.$attributes['editorTitleLineHeight'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-grid-author a span{
        color:'.$attributes['editorPostLinkColor'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-text-link a{
        color:'.$attributes['editorPostLinkColor'].';
    }';

    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-grid-date{
        color:'.$attributes['editorPostGeneralColor'].';
    }';
    $block_content .=' .'.$blockuniqueclass. ' .blockspare-banner-editor-picks-wrapper .comment_count{
        color:'.$attributes['editorPostGeneralColor'].';
    }';

     //sliderTitle Hover

  if($attributes['editorTitleOnHover']=='lpc-title-hover') {
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-posts-block-post-content.has-editor-title-hover .blockspare-posts-block-title-link:hover span{
        color: ' . $attributes['editorTitleOnHoverColor'] . ';
        
         }';
    }

if($attributes['editorTitleOnHover']=='lpc-title-border') {
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-posts-block-post-content.has-editor-title-hover .blockspare-posts-block-post-grid-title .blockspare-posts-block-title-link span:hover{
        box-shadow: inset 0 -2px 0 0 ' . $attributes['editorTitleOnHoverColor'] . ';
        
         }';
}

//editor title Gaps
$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-editor-picks-items  .blockspare-posts-block-post-grid-title{
    margin-top: ' . $attributes['editorTitleMarginTop'] ."px". ';
    margin-Bottom: ' . $attributes['editorTitleMarginBottom'] ."px". ';
    margin-left: ' . $attributes['editorTitleMarginLeft'] ."px". ';
    margin-right: ' . $attributes['editorTitleMarginRight'] ."px". ';
}';

//editor category Gaps
$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-editor-picks-items  .blockspare-posts-block-post-category{
    margin-top: ' . $attributes['editorCategoryMarginTop'] ."px". ';
    margin-Bottom: ' . $attributes['editorCategoryMarginBottom'] ."px". ';
    margin-left: ' . $attributes['editorCategoryMarginLeft'] ."px". ';
    margin-right: ' . $attributes['editorCategoryMarginRight'] ."px". ';
}';

//editor meta Gaps
$block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-editor-picks-items  .blockspare-posts-block-post-grid-byline{
    margin-top: ' . $attributes['editorMetaMarginTop'] ."px". ';
    margin-Bottom: ' . $attributes['editorMetaMarginBottom'] ."px". ';
    margin-left: ' . $attributes['editorMetaMarginLeft'] ."px". ';
    margin-right: ' . $attributes['editorMetaMarginRight'] ."px". ';
}';


    //Editor picks Category Color
    if ($attributes['editorCategoryLayoutOption'] == 'solid') {
        
       
        $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-category a{
        color:' . $attributes['editorCategoryTextColor'] . "!important" . ';
        background-color:' . $attributes['editorCategoryBackgroundColor'] . "!important" . ';
        border-radius:' . $attributes['editorCategoryBorderRadius'] . "px" . ';
    }';

    } else if ($attributes['editorCategoryLayoutOption'] == 'border') {
        
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-category a{
            color:' . $attributes['editorCategoryTextColor'] . "!important" . ';
            background-color:' . "transparent" . ';
            border:' . "1px solid" . $attributes['editorCategoryBorderColor'] . ';
            border-radius:' . $attributes['editorCategoryBorderRadius'] . "px" . ';
            border-width:' . $attributes['editorCategoryBorderWidth'] . "px" . ';
        }';
        
        
        
    } else {
        $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-category a{
            color:' . $attributes['editorCategoryTextColor'] . "!important" . ';
            }';
    }

    //Editor overlay color
    if($blockName == 'blockspare-banner-1' || $blockName == 'blockspare-banner-2' || $blockName == 'blockspare-banner-3' || $blockName == 'blockspare-banner-4'){
        if($attributes['bannerOneLayout'] === 'banner-style-1 has-bg-layout' || $attributes['bannerOneLayout'] === 'banner-style-2 has-bg-layout' || $attributes['bannerTwoLayout'] === 'banner-style-1 has-bg-layout' || $attributes['bannerTwoLayout'] === 'banner-style-2 has-bg-layout' || $attributes['bannerThreeLayout'] === 'banner-style-1 has-bg-layout' || $attributes['bannerThreeLayout'] === 'banner-style-2 has-bg-layout' || $attributes['bannerFourLayout'] === 'banner-style-1 has-bg-layout' || $attributes['bannerFourLayout'] === 'banner-style-2 has-bg-layout') {
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-post-items .blockspare-post-data .blockspare-posts-block-post-img::before{
                background:' . "linear-gradient(to bottom, rgba(0, 0, 0, 0) 40%, " . $attributes['editorPostOverlayColor'] . " 100%)" . ';
            }'; 
        }
        if($attributes['bannerOneLayout'] === 'banner-style-3 has-bg-layout' || $attributes['bannerOneLayout'] === 'banner-style-4 has-bg-layout' || $attributes['bannerTwoLayout'] === 'banner-style-3 has-bg-layout' || $attributes['bannerTwoLayout'] === 'banner-style-4 has-bg-layout' || $attributes['bannerThreeLayout'] === 'banner-style-3 has-bg-layout' || $attributes['bannerThreeLayout'] === 'banner-style-4 has-bg-layout' || $attributes['bannerFourLayout'] === 'banner-style-3 has-bg-layout' || $attributes['bannerFourLayout'] === 'banner-style-4 has-bg-layout') {
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-post-items .blockspare-post-data .blockspare-posts-block-post-content .blockspare-posts-block-post-grid-title .blockspare-posts-block-title-link{
                background:' . $attributes['editorPostOverlayColor'] . ';
            }'; 

            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-post-items .blockspare-post-data .blockspare-posts-block-post-content .blockspare-posts-block-post-grid-byline{
                background:' . $attributes['editorPostOverlayColor'] . ';
            }'; 
        }
        if($attributes['bannerOneLayout'] === 'banner-style-5' || $attributes['bannerOneLayout'] === 'banner-style-6' || $attributes['bannerTwoLayout'] === 'banner-style-5' || $attributes['bannerTwoLayout'] === 'banner-style-6' || $attributes['bannerThreeLayout'] === 'banner-style-5' || $attributes['bannerThreeLayout'] === 'banner-style-6' || $attributes['bannerFourLayout'] === 'banner-style-5' || $attributes['bannerFourLayout'] === 'banner-style-6') {
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-post-items .blockspare-post-data .blockspare-posts-block-post-content::after{
                background:' . $attributes['editorPostOverlayColor'] . ';
            }'; 
        }
        if($attributes['bannerOneLayout'] === 'banner-style-7' || $attributes['bannerOneLayout'] === 'banner-style-8' || $attributes['bannerTwoLayout'] === 'banner-style-7' || $attributes['bannerTwoLayout'] === 'banner-style-8' || $attributes['bannerThreeLayout'] === 'banner-style-7' || $attributes['bannerThreeLayout'] === 'banner-style-8' || $attributes['bannerFourLayout'] === 'banner-style-7' || $attributes['bannerFourLayout'] === 'banner-style-8') {
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-post-items .blockspare-post-data .blockspare-posts-block-post-img::before{
                background:' . $attributes['editorPostOverlayColor'] . ';
            }'; 
        }
    } else {
        $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-post-items .blockspare-post-data .blockspare-posts-block-post-img::before{
            background:' . "linear-gradient(to bottom, rgba(0, 0, 0, 0) 40%, " . $attributes['editorPostOverlayColor'] . " 100%)" . ';
        }'; 
    }


    //Trending carousel Category Color
    if ($attributes['trendingCategoryLayoutOption'] == 'solid') {
        
       
        $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-category a{
        color:' . $attributes['trendingCategoryTextColor'] . "!important" . ';
        background-color:' . $attributes['trendingCategoryBackgroundColor'] . "!important" . ';
        border-radius:' . $attributes['trendingCategoryBorderRadius'] . "px" . ';
    }';

    } else if ($attributes['trendingCategoryLayoutOption'] == 'border') {
        
            $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-category a{
            color:' . $attributes['trendingCategoryTextColor'] . "!important" . ';
            background-color:' . "transparent" . ';
            border:' . "1px solid" . $attributes['trendingCategoryBorderColor'] . ';
            border-radius:' . $attributes['trendingCategoryBorderRadius'] . "px" . ';
            border-width:' . $attributes['trendingCategoryBorderWidth'] . "px" . ';
        }';
        
        
        
    } else {
        $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-category a{
            color:' . $attributes['trendingCategoryTextColor'] . "!important" . ';
            }';
    }
    

    /**
     * Font Size styles
     */

    //Slider Title Font size
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-post-items .blockspare-posts-block-post-grid-title{
          
        font-size: ' . $attributes['sliderTitleFontSize'] . $attributes['sliderTitleFontSizeType'] . ';
        '.bscheckFontfamily($attributes['sliderTitleFontFamily']).';
        font-weight: ' . $attributes['sliderTitleFontWeight'] . ';
      
         }';

    //Category Fornt
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-category a{
          
        font-size: ' . $attributes['sliderCategoryFontSize'] . $attributes['sliderTitleFontSizeType'] . ';
        '.bscheckFontfamily($attributes['sliderCategoryFontFamily']).';
        font-weight: ' . $attributes['sliderCategoryFontWeight'] . ';
          
             }';

    //Editor picks
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-post-items .blockspare-posts-block-post-grid-title{
          
        font-size: ' . $attributes['editorTitleFontSize'] . $attributes['editorTitleFontSizeType'] . ';
        
        '.bscheckFontfamily($attributes['editorTitleFontFamily']).';
        font-weight: ' . $attributes['editorTitleFontWeight'] . ';
      
         }';

         $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-category a{
          
            font-size: ' . $attributes['editorCategoryFontSize'] . $attributes['editorTitleFontSizeType'] . ';
            '.bscheckFontfamily($attributes['editorCategoryFontFamily']).';
            font-weight: ' . $attributes['editorCategoryFontWeight'] . ';
              
                 }';
    //Trending Carousel


    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .blockspare-post-items .blockspare-posts-block-post-grid-title {
          
        font-size: ' . $attributes['trendingTitleFontSize'] . $attributes['trendingTitleFontSizeType'] . ';
        
        '.bscheckFontfamily($attributes['trendingTitleFontFamily']).';
        font-weight: ' . $attributes['trendingTitleFontWeight'] . ';
          
        }';

        $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .blockspare-posts-block-post-category a{
          
            font-size: ' . $attributes['trendingCategoryFontSize'] . $attributes['trendingTitleFontSizeType'] . ';
            '.bscheckFontfamily($attributes['trendingCategoryFontFamily']).';
            font-weight: ' . $attributes['trendingCategoryFontWeight'] . ';
              
                 }';

    //Slider Meta
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-grid-author a span{
            
        font-size: ' . $attributes['sliderMetaFontSize'] . $attributes['sliderMetaFontSizeType'] . ';
        '.bscheckFontfamily($attributes['sliderMetaFontFamily']).';
        font-weight: ' . $attributes['sliderMetaFontWeight'] . ';
    
    }'; 
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-grid-date{
        
        font-size: ' . $attributes['sliderMetaFontSize'] . $attributes['sliderMetaFontSizeType'] . ';
        '.bscheckFontfamily($attributes['sliderMetaFontFamily']).';
        font-weight: ' . $attributes['sliderMetaFontWeight'] . ';
    
    }'; 

    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .comment_count{
    
        font-size: ' . $attributes['sliderMetaFontSize'] . $attributes['sliderMetaFontSizeType'] . ';
        '.bscheckFontfamily($attributes['sliderMetaFontFamily']).';
        font-weight: ' . $attributes['sliderMetaFontWeight'] . ';
    
    }'; 
    //Editor picks Meta
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-grid-author a span{
          
        font-size: ' . $attributes['editorMetaFontSize'] . $attributes['editorTitleFontSizeType'] . ';
        '.bscheckFontfamily($attributes['editorMetaFontFamily']).';
        font-weight: ' . $attributes['editorMetaFontWeight'] . ';
      
    }'; 
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-grid-date{
          
        font-size: ' . $attributes['editorMetaFontSize'] . $attributes['editorTitleFontSizeType'] . ';
        '.bscheckFontfamily($attributes['editorMetaFontFamily']).';
        font-weight: ' . $attributes['editorMetaFontWeight'] . ';
      
    }'; 
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .comment_count{
          
        font-size: ' . $attributes['editorMetaFontSize'] . $attributes['editorTitleFontSizeType'] . ';
        '.bscheckFontfamily($attributes['editorMetaFontFamily']).';
        font-weight: ' . $attributes['editorMetaFontWeight'] . ';
      
    }'; 

    //Trending Carousel Meta
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper  .blockspare-posts-block-post-grid-author a span{
            
        font-size: ' . $attributes['trendingMetaFontSize'] . $attributes['trendingMetaFontSizeType'] . ';
        '.bscheckFontfamily($attributes['trendingMetaFontFamily']).';
        font-weight: ' . $attributes['trendingMetaFontWeight'] . ';
        
    }';
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper  .blockspare-posts-block-post-grid-date{
            
        font-size: ' . $attributes['trendingMetaFontSize'] . $attributes['trendingMetaFontSizeType'] . ';
        '.bscheckFontfamily($attributes['trendingMetaFontFamily']).';
        font-weight: ' . $attributes['trendingMetaFontWeight'] . ';
        
    }';
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper  .comment_count{
            
        font-size: ' . $attributes['trendingMetaFontSize'] . $attributes['trendingMetaFontSizeType'] . ';
        '.bscheckFontfamily($attributes['trendingMetaFontFamily']).';
        font-weight: ' . $attributes['trendingMetaFontWeight'] . ';
        
    }';

    // trending tab font size
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper  .blockspare-trending-tabs .components-tab-panel__tabs .blockspare-trending-tab{
            
        font-size: ' . $attributes['trendingTabFontSize'] . $attributes['trendingTabFontSizeType'] . ';
        '.bscheckFontfamily($attributes['trendingTabFontFamily']).';
        font-weight: ' . $attributes['trendingTabFontWeight'] . ';
        
    }';

    $block_content .= '@media (max-width: 1025px) { ';
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-post-items .blockspare-posts-block-post-grid-title{
        font-size: ' . $attributes['sliderTitleFontSizeTablet'] . $attributes['sliderTitleFontSizeType'] . ';
        }';

    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-category a{
          
        font-size: ' . $attributes['sliderCategoryFontSizeTablet'] . $attributes['sliderTitleFontSizeType'] . ';    
    }';

    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-post-items .blockspare-posts-block-post-grid-title{
        font-size: ' . $attributes['editorTitleFontSizeTablet'] . $attributes['editorTitleFontSizeType'] . ';
        }'; 

        $block_content .= ' .' . $blockuniqueclass . ' .blockspare-editor-picks-wrapper .blockspare-posts-block-post-category a{
          
            font-size: ' . $attributes['editorCategoryFontSizeTablet'] . $attributes['editorTitleFontSizeType'] . ';    
            }';
        
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .blockspare-post-items .blockspare-posts-block-post-grid-title{
          
        font-size: ' . $attributes['trendingTitleFontSizeTablet'] . $attributes['trendingTitleFontSizeType'] . ';          
        }';

         $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .blockspare-post-items .blockspare-posts-block-post-grid-title{
          
        font-size: ' . $attributes['trendingTitleFontSizeTablet'] . $attributes['trendingTitleFontSizeType'] . ';          
        }';
    
    //Meta
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-grid-author a span, .blockspare-banner-slider-wrapper .blockspare-posts-block-post-grid-date, .blockspare-banner-slider-wrapper .comment_count{
        font-size: ' . $attributes['sliderMetaFontSizeTablet'] . $attributes['sliderTitleFontSizeType'] . ';
        }';
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-grid-author a span, .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-grid-date, .blockspare-banner-editor-picks-wrapper .comment_count{
        font-size: ' . $attributes['editorMetaFontSizeTablet'] . $attributes['sliderTitleFontSizeType'] . ';
        }'; 
    
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper  .blockspare-posts-block-post-grid-author a span, .blockspare-banner-trending-carousel-wrapper  .blockspare-posts-block-post-grid-date, .blockspare-banner-trending-carousel-wrapper  .comment_count{
        font-size: ' . $attributes['trendingMetaFontSizeTablet'] . $attributes['trendingMetaFontSizeType'] . ';
        }';
    //End Meta  
    
    // trending tab font size  
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper  .blockspare-trending-tabs .components-tab-panel__tabs .blockspare-trending-tab{
        font-size: ' . $attributes['trendingTabFontSizeTablet'] . $attributes['trendingTabFontSizeType'] . ';
        }';
    
    $block_content .= '}';

    $block_content .= '@media (max-width: 767px) { ';
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-post-items .blockspare-posts-block-post-grid-title{
        font-size: ' . $attributes['sliderTitleFontSizeMobile'] . $attributes['sliderTitleFontSizeType'] . ';
        }';

    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-category a{
          
        font-size: ' . $attributes['sliderCategoryFontSizeMobile'] . $attributes['sliderTitleFontSizeType'] . ';    
        }';

    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-post-items .blockspare-posts-block-post-grid-title{
        font-size: ' . $attributes['editorTitleFontSizeMobile'] . $attributes['editorTitleFontSizeType'] . ';
        }';


        $block_content .= ' .' . $blockuniqueclass . ' .blockspare-editor-picks-wrapper .blockspare-posts-block-post-category a{
          
            font-size: ' . $attributes['editorCategoryFontSizeMobile'] . $attributes['editorTitleFontSizeType'] . ';    
            }';
    
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper .blockspare-post-items .blockspare-posts-block-post-grid-title{
        font-size: ' . $attributes['trendingTitleFontSizeMobile'] . $attributes['trendingTitleFontSizeType'] . ';          
        }';

    //Meta
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-slider-wrapper .blockspare-posts-block-post-grid-author a span, .blockspare-banner-slider-wrapper .blockspare-posts-block-post-grid-date, .blockspare-banner-slider-wrapper .comment_count{
        font-size: ' . $attributes['sliderMetaFontSizeMobile'] . $attributes['sliderTitleFontSizeType'] . ';
        }';
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-grid-author a span, .blockspare-banner-editor-picks-wrapper .blockspare-posts-block-post-grid-date, .blockspare-banner-editor-picks-wrapper .comment_count{
        font-size: ' . $attributes['editorMetaFontSizeMobile'] . $attributes['sliderTitleFontSizeType'] . ';
        }'; 
    
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper  .blockspare-posts-block-post-grid-author a span, .blockspare-banner-trending-carousel-wrapper  .blockspare-posts-block-post-grid-date, .blockspare-banner-trending-carousel-wrapper  .comment_count{
        font-size: ' . $attributes['trendingMetaFontSizeMobile'] . $attributes['trendingMetaFontSizeType'] . ';
        }';
        
    // trending tab font size
    $block_content .= ' .' . $blockuniqueclass . ' .blockspare-banner-trending-carousel-wrapper  .blockspare-trending-tabs .components-tab-panel__tabs .blockspare-trending-tab{
        font-size: ' . $attributes['trendingTabFontSizeMobile'] . $attributes['trendingTabFontSizeType'] . ';
        }';



    $block_content .='</style>';
    return $block_content;
}