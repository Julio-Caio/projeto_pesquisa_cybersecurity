<div v-if="isoEmbedsEnabled()">
    <div class="sb-two-column-box sb-plugin-info-box">
        <div class="sb-left">
            <img :src="images.image4_2x" alt="">
        </div>
        <div class="sb-right sb-embed-info-text">
            <h4>{{genericText.displayACompletely}}</h4>
            <p>{{genericText.createACustom}}</p>
        </div>
    </div>
</div>